#include "stdafx.h"
#include "IState.h"

using namespace std;

IState::IState()
{

}

IState::~IState()
{

}

void IState::ChangeState(IState * state)
{

}

void IState::PushState(IState * state)
{

}

void IState::PopState(IState * state)
{

}
