#include "stdafx.h"
#include "IState.h"